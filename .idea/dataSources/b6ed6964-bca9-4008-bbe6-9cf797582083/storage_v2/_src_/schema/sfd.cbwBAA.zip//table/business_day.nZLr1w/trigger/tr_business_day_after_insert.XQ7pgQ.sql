create trigger tr_business_day_after_insert
  after INSERT
  on business_day
  for each row
  insert history.business_day values(
		 new.`id`
		, new.`version`
		, new.`business`
		, new.`date`
		, new.`date_created`
		, new.`last_updated`
		, new.`user_created`
		, new.`user_updated`
	, null, 'insert', sysdate());

