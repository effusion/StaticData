create trigger tr_sub_fund_distributors_after_insert
  after INSERT
  on sub_fund_distributors
  for each row
  insert history.sub_fund_distributors values(
		 new.`sub_fund_distributors_id`
		, new.`partner_contact_id`
	, null, 'insert', sysdate());

