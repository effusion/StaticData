create trigger tr_unit_share_partner_after_delete
  after DELETE
  on unit_share_partner
  for each row
  insert history.unit_share_partner values(
		 old.`unit_share_recipients_id`
		, old.`partner_id`
	, null, 'delete', sysdate());

