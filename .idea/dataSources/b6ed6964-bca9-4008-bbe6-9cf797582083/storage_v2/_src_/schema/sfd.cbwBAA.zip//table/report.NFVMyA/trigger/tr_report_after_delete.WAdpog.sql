create trigger tr_report_after_delete
  after DELETE
  on report
  for each row
  insert history.report values(
		 old.`id`
		, old.`version`
		, old.`content_meta_data_id`
		, old.`date`
		, old.`date_created`
		, old.`last_updated`
		, old.`name`
		, old.`partner_id`
		, old.`type`
		, old.`user_created`
		, old.`user_updated`
	, null, 'delete', sysdate());

