create trigger tr_web_document_after_update
  after UPDATE
  on web_document
  for each row
  insert history.web_document values(
		 new.`id`
		, new.`version`
		, new.`category`
		, new.`content_meta_data_id`
		, new.`date_created`
		, new.`description`
		, new.`filename`
		, new.`key_date`
		, new.`language`
		, new.`last_updated`
		, new.`user_created`
		, new.`user_updated`
	, null, 'update', sysdate());

