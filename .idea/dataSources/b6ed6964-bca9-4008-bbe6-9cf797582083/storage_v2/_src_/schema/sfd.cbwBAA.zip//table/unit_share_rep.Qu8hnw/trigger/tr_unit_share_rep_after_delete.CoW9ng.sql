create trigger tr_unit_share_rep_after_delete
  after DELETE
  on unit_share_rep
  for each row
  insert history.unit_share_rep values(
		 old.`id`
		, old.`version`
		, old.`asset_dev_rep_id`
		, old.`ch_cash_inflow`
		, old.`ch_cash_outflow`
		, old.`ch_new_issued`
		, old.`ch_outstanding`
		, old.`ch_price`
		, old.`ch_redeemed`
		, old.`date_created`
		, old.`last_updated`
		, old.`tot_cash_inflow`
		, old.`tot_cash_outflow`
		, old.`tot_new_issued`
		, old.`tot_outstanding`
		, old.`tot_price`
		, old.`tot_redeemed`
		, old.`unit_share_id`
		, old.`user_created`
		, old.`user_updated`
	, null, 'delete', sysdate());

