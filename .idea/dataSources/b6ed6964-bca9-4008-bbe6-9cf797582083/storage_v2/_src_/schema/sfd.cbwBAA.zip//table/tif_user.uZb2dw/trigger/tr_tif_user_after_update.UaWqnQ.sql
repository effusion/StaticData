create trigger tr_tif_user_after_update
  after UPDATE
  on tif_user
  for each row
  insert history.tif_user values(
    new.`id`,
    new.`version`,
    new.`date_created`,
    new.`last_login`,
    new.`last_updated`,
    new.`mail`,
    new.`name`,
    new.`partner_id`,
    new.`password`,
    new.`public_key`,
    new.`receives_daily_price_reminder`,
    new.`role`,
    new.`user_created`,
    new.`user_updated`,
    new.`username`,
    null, 'update', sysdate());

