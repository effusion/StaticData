create trigger tr_ter_price_after_update
  after UPDATE
  on ter_price
  for each row
  insert history.ter_price values(
        new.`id`,
        new.`version`,
        new.`date_created`,
        new.`last_updated`,
        new.`ter_calculation_date`,
        null,
        null,
        new.`ter_ptr`,
        new.`ter_value`,
        new.`unit_share_id`,
        new.`user_created`,
        new.`user_updated`,
        null, 'update', sysdate());

