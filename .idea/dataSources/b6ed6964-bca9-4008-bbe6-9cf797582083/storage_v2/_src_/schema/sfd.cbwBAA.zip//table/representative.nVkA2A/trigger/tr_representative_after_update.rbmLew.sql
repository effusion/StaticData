create trigger tr_representative_after_update
  after UPDATE
  on representative
  for each row
  insert history.representative values(
     new.`id`
		,new.`version`
    ,new.`partner_id`
    ,null, 'update', sysdate());

