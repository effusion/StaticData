create trigger tr_shab_document_after_delete
  after DELETE
  on shab_document
  for each row
  insert history.shab_document values(
    old.id,
    old.version,
    old.date_created,
    old.doc_type,
    old.file_name,
    old.key_date,
    old.language,
    old.last_updated,
    old.published,
    old.sfd_id,
    old.shab_id,
    old.user_created,
    old.user_updated,

	null, 'delete', sysdate());

