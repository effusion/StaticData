create trigger tr_my_fund_user_after_insert
  after INSERT
  on my_fund_user
  for each row
  insert history.my_fund_user values(
		 new.`id`
		, new.`version`
		, new.`enabled`
		, new.`language`
		, new.`last_login`
		, new.`last_login_failure`
		, new.`last_login_ip`
		, new.`last_password_change`
		, new.`login_failures`
		, new.`password`
		, new.`registered`
		, new.`role`
		, new.`unlock_code`
		, new.`unlocked`
		, new.`user_id`
	, null, 'insert', sysdate());

