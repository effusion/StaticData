create trigger tr_global_contact_after_insert
  after INSERT
  on global_contact
  for each row
  insert history.global_contact values(
		 new.`id`
		, new.`version`
		, new.`city`
		, new.`country`
		, new.`date_created`
		, new.`last_updated`
		, new.`mail`
		, new.`name`
		, new.`phone`
		, new.`role`
		, new.`street`
		, new.`url`
		, new.`user_created`
		, new.`user_updated`
		, new.`zip_code`
    , null
    , 'insert'
    , sysdate());

