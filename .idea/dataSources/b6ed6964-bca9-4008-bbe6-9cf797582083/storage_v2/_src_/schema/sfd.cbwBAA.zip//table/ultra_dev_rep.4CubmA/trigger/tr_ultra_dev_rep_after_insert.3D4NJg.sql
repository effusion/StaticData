create trigger tr_ultra_dev_rep_after_insert
  after INSERT
  on ultra_dev_rep
  for each row
  insert history.ultra_dev_rep values(
    new.`id`,
    new.`version`,
    new.`ch_cash_inflow`,
    new.`ch_cash_outflow`,
    new.`ch_net_assets`,
    new.`ch_net_cashflow`,
    new.`date_created`,
    new.`key_date`,
    new.`last_updated`,
    new.`reporting_currency`,
    new.`unit_share_id`,
    new.`tot_cash_inflow`,
    new.`tot_cash_outflow`,
    new.`tot_net_assets`,
    new.`tot_net_cashflow`,
    new.`user_created`,
    new.`user_updated`,
    null, 'insert', sysdate());

