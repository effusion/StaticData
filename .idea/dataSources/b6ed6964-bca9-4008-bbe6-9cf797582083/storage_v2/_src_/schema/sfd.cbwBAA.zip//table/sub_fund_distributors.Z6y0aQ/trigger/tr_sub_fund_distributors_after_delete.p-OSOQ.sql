create trigger tr_sub_fund_distributors_after_delete
  after DELETE
  on sub_fund_distributors
  for each row
  insert history.sub_fund_distributors values(
		 old.`sub_fund_distributors_id`
		, old.`partner_contact_id`
	, null, 'delete', sysdate());

