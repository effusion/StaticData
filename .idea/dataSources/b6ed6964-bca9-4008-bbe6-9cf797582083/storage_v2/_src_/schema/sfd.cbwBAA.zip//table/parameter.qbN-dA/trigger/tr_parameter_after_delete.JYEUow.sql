create trigger tr_parameter_after_delete
  after DELETE
  on parameter
  for each row
  insert history.parameter values(
		 old.`id`
		, old.`version`
		, old.`date_created`
		, old.`last_updated`
		, old.`name`
		, old.`user_created`
		, old.`user_updated`
		, old.`value`
	, null, 'delete', sysdate());

