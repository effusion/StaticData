create trigger tr_news_content_languages_after_update
  after UPDATE
  on news_content_languages
  for each row
  insert history.news_content_languages values(
	  new.`news_content_id`
	, new.`languages_string`
	, null, 'update', sysdate());

