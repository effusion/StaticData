create trigger tr_snb_report_after_delete
  after DELETE
  on snb_report
  for each row
  insert history.snb_report values(
    old.`id`
    , old.`version`
    , old.`asset_struct_rep_id`
    , old.`content_meta_data_id`
    , old.`date_created`
    , old.`last_updated`
    , old.`name`
    , old.`user_created`
    , old.`user_updated`
    , null, 'delete', sysdate()
);

