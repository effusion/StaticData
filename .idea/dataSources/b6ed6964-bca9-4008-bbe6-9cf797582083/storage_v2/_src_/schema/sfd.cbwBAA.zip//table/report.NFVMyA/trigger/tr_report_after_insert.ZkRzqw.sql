create trigger tr_report_after_insert
  after INSERT
  on report
  for each row
  insert history.report values(
		 new.`id`
		, new.`version`
		, new.`content_meta_data_id`
		, new.`date`
		, new.`date_created`
		, new.`last_updated`
		, new.`name`
		, new.`partner_id`
		, new.`type`
		, new.`user_created`
		, new.`user_updated`
	, null, 'insert', sysdate());

