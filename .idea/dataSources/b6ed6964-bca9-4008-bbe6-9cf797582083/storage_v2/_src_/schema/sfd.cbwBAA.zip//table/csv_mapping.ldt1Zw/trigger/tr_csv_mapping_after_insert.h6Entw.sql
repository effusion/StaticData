create trigger tr_csv_mapping_after_insert
  after INSERT
  on csv_mapping
  for each row
  insert history.csv_mapping values(
  	new.`id`,
    new.`version`,
    new.`field`,
    new.`kind`,
    new.`label`,
    new.`participant_id`,
    new.`participant_key`,
  	null, 'insert', sysdate());

