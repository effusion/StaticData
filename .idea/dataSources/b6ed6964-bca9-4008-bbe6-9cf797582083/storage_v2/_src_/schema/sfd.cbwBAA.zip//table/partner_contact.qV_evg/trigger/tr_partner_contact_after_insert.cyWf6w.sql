create trigger tr_partner_contact_after_insert
  after INSERT
  on partner_contact
  for each row
  insert history.partner_contact values(
		 new.`id`
		, new.`version`
		, new.`city`
		, new.`country`
		, new.`date_created`
		, new.`last_updated`
		, new.`mail`
		, new.`name`
		, new.`partner_id`
		, new.`phone`
		, new.`reference`
		, new.`role`
		, new.`street`
		, new.`url`
		, new.`user_created`
		, new.`user_updated`
		, new.`zip_code`
	, null, 'insert', sysdate());

