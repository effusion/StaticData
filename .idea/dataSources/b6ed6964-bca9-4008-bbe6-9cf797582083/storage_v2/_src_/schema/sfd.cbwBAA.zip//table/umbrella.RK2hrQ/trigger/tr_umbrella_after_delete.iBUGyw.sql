create trigger tr_umbrella_after_delete
  after DELETE
  on umbrella
  for each row
  insert history.umbrella values(
		 old.`id`
		, old.`version`
		, old.`auditor`
		, old.`civ_id`
		, old.`civ_type`
		, old.`company`
		, old.`ctrl_data_status`
		, old.`date_created`
		, old.`depositary_bank`
		, old.`disp_status`
		, old.`end_of_fiscal_year`
		, old.`generic_name`
		, old.`home_country`
		, old.`is_self_managed`
		, old.`last_updated`
		, old.`legal_form`
		, old.`legal_status`
		, old.`maturity_type`
		, old.`organisational_structure`
		, old.`participant_id`
		, old.`type_code`
		, old.`user_created`
		, old.`user_updated`
	, null, 'delete', sysdate());

