create trigger tr_promoter_mail_after_insert
  after INSERT
  on promoter_mail
  for each row
  insert history.promoter_mail values(
		 new.`id`
		, new.`version`
    , new.`announcement`
		, new.`email`
		, new.`language`
		, new.`legal`
    , new.`marketing`
		, new.`promoter_id`
	, null, 'insert', sysdate());

