create trigger tr_fund_document_after_delete
  after DELETE
  on fund_document
  for each row
  insert history.fund_document values(
		 old.`id`
		, old.`version`
		, old.`content_meta_data_id`
		, old.`date_created`
		, old.`doc_type`
		, old.`key_date`
		, old.`language`
		, old.`last_updated`
		, old.`my_funds_mail`
		, old.`participant_id`
		, old.`promoter_mail`
		, old.`reporting_date`
		, old.`tif_id`
		, old.`user_created`
		, old.`user_updated`
	, null, 'delete', sysdate());

