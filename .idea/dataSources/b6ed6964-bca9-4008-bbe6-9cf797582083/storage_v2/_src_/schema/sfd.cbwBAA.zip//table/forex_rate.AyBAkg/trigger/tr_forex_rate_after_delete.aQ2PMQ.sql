create trigger tr_forex_rate_after_delete
  after DELETE
  on forex_rate
  for each row
  insert history.forex_rate values(
		 old.`id`
		, old.`version`
		, old.`currency`
		, old.`date`
		, old.`date_created`
		, old.`last_updated`
		, old.`user_created`
		, old.`user_updated`
		, old.`value`
	, null, 'delete', sysdate());

