create trigger tr_sub_fund_after_delete
  after DELETE
  on sub_fund
  for each row
  insert history.sub_fund values(
		 old.`id`
		, old.`version`
		, old.`accounting_currency`
		, old.`benchmark`
		, old.`ch_fbc_registration_date`
		, old.`ch_paying_agent`
		, old.`ch_representative_id`
		, old.`ch_snb_code`
		, old.`civ_org_struct`
		, old.`ctrl_accounting_debtor_number`
		, old.`ctrl_asset_dev_reporting_type`
		, old.`ctrl_ch_is_asset_struc_rep_del`
		, old.`ctrl_data_status`
		, old.`ctrl_in_liquidation`
		, old.`date_created`
		, old.`disp_status`
		, old.`has_qualified_investors_only`
		, old.`ig_alternative_assets`
		, old.`ig_asset_class`
		, old.`ig_basic_hedge_strategy`
		, old.`ig_borrowers_type`
		, old.`ig_company_size`
		, old.`ig_credit_quality`
		, old.`ig_economic_sectors`
		, old.`ig_interest_rate_exposure`
		, old.`ig_investment_ccy_single_ccy`
		, old.`ig_investment_countries`
		, old.`ig_investment_ctry_excl_ctry`
		, old.`ig_investment_ctry_single_ctry`
		, old.`ig_investment_currencies`
		, old.`ig_investment_objective_aaf`
		, old.`ig_management_style_strategy`
		, old.`ig_other_funds_type`
		, old.`ig_reference_currency`
		, old.`ig_stock_characteristics`
		, old.`ig_sub_hedge_strategy`
		, old.`investment_objective`
		, old.`is_fund_of_fund`
		, old.`last_updated`
		, old.`launch_date`
		, old.`liquidation_month`
		, old.`name`
		, old.`participant_id`
		, old.`promoter_id`
		, old.`sf_id`
		, old.`short_name`
		, old.`umbrella_id`
		, old.`user_created`
		, old.`ref_sub_classification`
		, old.`investment_managers`
		, old.`user_updated`
	, null, 'delete', sysdate());

