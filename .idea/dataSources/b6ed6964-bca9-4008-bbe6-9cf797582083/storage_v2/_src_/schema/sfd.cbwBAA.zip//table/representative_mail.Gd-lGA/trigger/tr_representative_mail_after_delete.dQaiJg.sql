create trigger tr_representative_mail_after_delete
  after DELETE
  on representative_mail
  for each row
  insert history.representative_mail values(
     old.`id`
		,old.`version`
    ,old.`announcement`
    ,old.`email`
    ,old.`language`
    ,old.`legal`
    ,old.`marketing`
		,old.`representative_id`
    ,null, 'delete', sysdate());

