create trigger tr_html_text_after_delete
  after DELETE
  on html_text
  for each row
  insert history.html_text values(
	  old.`id`
	  , old.`version`
	  , old.`name`
	  , old.`text`
	  , null, 'delete', sysdate());

