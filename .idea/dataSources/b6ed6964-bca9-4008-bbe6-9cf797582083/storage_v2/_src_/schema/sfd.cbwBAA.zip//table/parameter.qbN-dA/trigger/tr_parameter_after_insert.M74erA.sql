create trigger tr_parameter_after_insert
  after INSERT
  on parameter
  for each row
  insert history.parameter values(
		 new.`id`
		, new.`version`
		, new.`date_created`
		, new.`last_updated`
		, new.`name`
		, new.`user_created`
		, new.`user_updated`
		, new.`value`
	, null, 'insert', sysdate());

