create trigger tr_forex_rate_after_update
  after UPDATE
  on forex_rate
  for each row
  insert history.forex_rate values(
		 new.`id`
		, new.`version`
		, new.`currency`
		, new.`date`
		, new.`date_created`
		, new.`last_updated`
		, new.`user_created`
		, new.`user_updated`
		, new.`value`
	, null, 'update', sysdate());

