create trigger tr_promoter_mail_after_delete
  after DELETE
  on promoter_mail
  for each row
  insert history.promoter_mail values(
		 old.`id`
		, old.`version`
    , old.`announcement`
		, old.`email`
		, old.`language`
		, old.`legal`
    , old.`marketing`
		, old.`promoter_id`
	, null, 'delete', sysdate());

