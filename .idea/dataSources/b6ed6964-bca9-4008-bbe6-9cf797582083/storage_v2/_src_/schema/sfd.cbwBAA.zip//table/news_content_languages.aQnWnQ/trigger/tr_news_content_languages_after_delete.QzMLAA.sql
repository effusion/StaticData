create trigger tr_news_content_languages_after_delete
  after DELETE
  on news_content_languages
  for each row
  insert history.news_content_languages values(
	  old.`news_content_id`
	, old.`languages_string`
	, null, 'delete', sysdate());

