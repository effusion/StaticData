create trigger tr_dyn_enum_after_insert
  after INSERT
  on dyn_enum
  for each row
  insert history.dyn_enum values(
		 new.`id`
		, new.`version`
		, new.`category`
		, new.`code`
		, new.`date_created`
		, new.`description`
		, new.`english`
		, new.`french`
		, new.`german`
		, new.`italian`
		, new.`last_updated`
		, new.`system`
		, new.`text`
		, new.`type`
		, new.`user_created`
		, new.`user_updated`
	, null, 'insert', sysdate());

