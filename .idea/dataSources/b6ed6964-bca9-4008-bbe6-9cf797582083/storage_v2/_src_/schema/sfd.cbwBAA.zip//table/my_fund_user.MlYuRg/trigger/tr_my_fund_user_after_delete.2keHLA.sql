create trigger tr_my_fund_user_after_delete
  after DELETE
  on my_fund_user
  for each row
  insert history.my_fund_user values(
		 old.`id`
		, old.`version`
		, old.`enabled`
		, old.`language`
		, old.`last_login`
		, old.`last_login_failure`
		, old.`last_login_ip`
		, old.`last_password_change`
		, old.`login_failures`
		, old.`password`
		, old.`registered`
		, old.`role`
		, old.`unlock_code`
		, old.`unlocked`
		, old.`user_id`
	, null, 'delete', sysdate());

