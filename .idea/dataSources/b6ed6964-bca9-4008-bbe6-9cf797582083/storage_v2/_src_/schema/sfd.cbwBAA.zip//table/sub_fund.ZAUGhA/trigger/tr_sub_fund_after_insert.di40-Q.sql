create trigger tr_sub_fund_after_insert
  after INSERT
  on sub_fund
  for each row
  insert history.sub_fund values(
		 new.`id`
		, new.`version`
		, new.`accounting_currency`
		, new.`benchmark`
		, new.`ch_fbc_registration_date`
		, new.`ch_paying_agent`
		, new.`ch_representative_id`
		, new.`ch_snb_code`
		, new.`civ_org_struct`
		, new.`ctrl_accounting_debtor_number`
		, new.`ctrl_asset_dev_reporting_type`
		, new.`ctrl_ch_is_asset_struc_rep_del`
		, new.`ctrl_data_status`
		, new.`ctrl_in_liquidation`
		, new.`date_created`
		, new.`disp_status`
		, new.`has_qualified_investors_only`
		, new.`ig_alternative_assets`
		, new.`ig_asset_class`
		, new.`ig_basic_hedge_strategy`
		, new.`ig_borrowers_type`
		, new.`ig_company_size`
		, new.`ig_credit_quality`
		, new.`ig_economic_sectors`
		, new.`ig_interest_rate_exposure`
		, new.`ig_investment_ccy_single_ccy`
		, new.`ig_investment_countries`
		, new.`ig_investment_ctry_excl_ctry`
		, new.`ig_investment_ctry_single_ctry`
		, new.`ig_investment_currencies`
		, new.`ig_investment_objective_aaf`
		, new.`ig_management_style_strategy`
		, new.`ig_other_funds_type`
		, new.`ig_reference_currency`
		, new.`ig_stock_characteristics`
		, new.`ig_sub_hedge_strategy`
		, new.`investment_objective`
		, new.`is_fund_of_fund`
		, new.`last_updated`
		, new.`launch_date`
		, new.`liquidation_month`
		, new.`name`
		, new.`participant_id`
		, new.`promoter_id`
		, new.`sf_id`
		, new.`short_name`
		, new.`umbrella_id`
		, new.`user_created`
		, new.`ref_sub_classification`
		, new.`investment_managers`
		, new.`user_updated`
	, null, 'insert', sysdate());

