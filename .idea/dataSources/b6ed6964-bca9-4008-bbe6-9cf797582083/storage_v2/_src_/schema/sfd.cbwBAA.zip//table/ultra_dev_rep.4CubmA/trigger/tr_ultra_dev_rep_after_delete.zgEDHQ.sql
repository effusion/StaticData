create trigger tr_ultra_dev_rep_after_delete
  after DELETE
  on ultra_dev_rep
  for each row
  insert history.ultra_dev_rep values(
    old.`id`,
    old.`version`,
    old.`ch_cash_inflow`,
    old.`ch_cash_outflow`,
    old.`ch_net_assets`,
    old.`ch_net_cashflow`,
    old.`date_created`,
    old.`key_date`,
    old.`last_updated`,
    old.`reporting_currency`,
    old.`unit_share_id`,
    old.`tot_cash_inflow`,
    old.`tot_cash_outflow`,
    old.`tot_net_assets`,
    old.`tot_net_cashflow`,
    old.`user_created`,
    old.`user_updated`,
    null, 'delete', sysdate());

