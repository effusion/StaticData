create trigger tr_message_after_delete
  after DELETE
  on message
  for each row
  insert history.message values(
    old.`id`,
    old.`version`,
    old.`body`,
    old.`content_type`,
    old.`date_created`,
    old.`last_updated`,
    old.`partner_id`,
    old.`subject`,
    old.`type`,
    old.`unread`,
    old.`user_created`,
    old.`user_updated`,
    old.`valid_from`,
    old.`valid_until`,
    null, 'delete', sysdate());

