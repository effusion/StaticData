create trigger tr_db_version_after_insert
  after INSERT
  on db_version
  for each row
  insert history.db_version values(
  	new.`tag`
  	, null
  	, null, 'insert', sysdate());

