create trigger tr_db_version_after_delete
  after DELETE
  on db_version
  for each row
  insert history.db_version values(
	  old.`tag`
  	, null
	  , null, 'delete', sysdate());

