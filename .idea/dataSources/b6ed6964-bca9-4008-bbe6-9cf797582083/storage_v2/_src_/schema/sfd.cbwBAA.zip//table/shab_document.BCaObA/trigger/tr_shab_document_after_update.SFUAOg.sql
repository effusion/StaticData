create trigger tr_shab_document_after_update
  after UPDATE
  on shab_document
  for each row
  insert history.shab_document values(
    new.id,
    new.version,
    new.date_created,
    new.doc_type,
    new.file_name,
    new.key_date,
    new.language,
    new.last_updated,
    new.published,
    new.sfd_id,
    new.shab_id,
    new.user_created,
    new.user_updated,

	null, 'update', sysdate());

