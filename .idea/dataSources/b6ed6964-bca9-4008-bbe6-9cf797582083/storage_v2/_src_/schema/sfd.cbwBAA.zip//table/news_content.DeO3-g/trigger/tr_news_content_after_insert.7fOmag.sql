create trigger tr_news_content_after_insert
  after INSERT
  on news_content
  for each row
  insert history.news_content values(
    new.`id`,
    new.`version`,
    new.`date_created`,
    new.`document_id`,
    new.`document_name`,
    new.`image_id`,
    new.`last_updated`,
    new.`partner_id`,
    new.`qualified_only`,
    new.`text`,
    new.`title`,
    new.`type`,
    new.`url`,
    new.`user_created`,
    new.`user_updated`,
    null, 'insert', sysdate());

