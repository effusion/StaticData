create trigger tr_fund_document_after_update
  after UPDATE
  on fund_document
  for each row
  insert history.fund_document values(
		 new.`id`
		, new.`version`
		, new.`content_meta_data_id`
		, new.`date_created`
		, new.`doc_type`
		, new.`key_date`
		, new.`language`
		, new.`last_updated`
		, new.`my_funds_mail`
		, new.`participant_id`
		, new.`promoter_mail`
		, new.`reporting_date`
		, new.`tif_id`
		, new.`user_created`
		, new.`user_updated`
	, null, 'update', sysdate());

