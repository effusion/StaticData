create trigger tr_csv_mapping_after_delete
  after DELETE
  on csv_mapping
  for each row
  insert history.csv_mapping values(
    old.`id`,
    old.`version`,
    old.`field`,
    old.`kind`,
    old.`label`,
    old.`participant_id`,
    old.`participant_key`,
    null, 'delete', sysdate());

