create trigger tr_my_fund_user_unit_share_after_update
  after UPDATE
  on my_fund_user_unit_share
  for each row
  insert history.my_fund_user_unit_share values(
		 new.`my_fund_user_unit_shares_id`
		, new.`unit_share_id`
	, null, 'update', sysdate());

