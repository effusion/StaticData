create trigger tr_partner_after_delete
  after DELETE
  on partner
  for each row
  insert history.partner values(
    old.`id`,
    old.`version`,
    old.`city`,
    old.`country`,
    old.`date_created`,
    old.`document_report_mail`,
    old.`last_updated`,
    old.`mail`,
    old.`name`,
    old.`phone`,
    old.`price_import_mail`,
    old.`price_publication_mail`,
    old.`price_publication_time`,
    old.`price_report_mail`,
    old.`recipients_group`,
    old.`role`,
    old.`standard_price_publication`,
    old.`street`,
    old.`trade_association_membership`,
    old.`url`,
    old.`user_created`,
    old.`user_updated`,
    old.`zip_code`,
    null, 'delete', sysdate());

