create trigger tr_promoter_after_delete
  after DELETE
  on promoter
  for each row
  insert history.promoter values(
	 old.`id`
	, old.`version`
    , old.field_type1
    , old.field_type2
    , old.field_type3
    , old.field_type4
    , old.field_type5
	, old.`logo_id`
	, old.`overriding_group_of_promoter_id`
	, old.`partner_id`
    , null	, null, 'delete', sysdate());

