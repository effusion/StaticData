create trigger tr_partner_after_insert
  after INSERT
  on partner
  for each row
  insert history.partner values(
    new.`id`,
    new.`version`,
    new.`city`,
    new.`country`,
    new.`date_created`,
    new.`document_report_mail`,
    new.`last_updated`,
    new.`mail`,
    new.`name`,
    new.`phone`,
    new.`price_import_mail`,
    new.`price_publication_mail`,
    new.`price_publication_time`,
    new.`price_report_mail`,
    new.`recipients_group`,
    new.`role`,
    new.`standard_price_publication`,
    new.`street`,
    new.`trade_association_membership`,
    new.`url`,
    new.`user_created`,
    new.`user_updated`,
    new.`zip_code`,
    null, 'insert', sysdate());

