create trigger tr_umbrella_after_insert
  after INSERT
  on umbrella
  for each row
  insert history.umbrella values(
		 new.`id`
		, new.`version`
		, new.`auditor`
		, new.`civ_id`
		, new.`civ_type`
		, new.`company`
		, new.`ctrl_data_status`
		, new.`date_created`
		, new.`depositary_bank`
		, new.`disp_status`
		, new.`end_of_fiscal_year`
		, new.`generic_name`
		, new.`home_country`
		, new.`is_self_managed`
		, new.`last_updated`
		, new.`legal_form`
		, new.`legal_status`
		, new.`maturity_type`
		, new.`organisational_structure`
		, new.`participant_id`
		, new.`type_code`
		, new.`user_created`
		, new.`user_updated`
	, null, 'insert', sysdate());

