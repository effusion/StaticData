create trigger tr_ter_price_after_delete
  after DELETE
  on ter_price
  for each row
  insert history.ter_price values(
        old.`id`,
        old.`version`,
        old.`date_created`,
        old.`last_updated`,
        old.`ter_calculation_date`,
        null,
        null,
        old.`ter_ptr`,
        old.`ter_value`,
        old.`unit_share_id`,
        old.`user_created`,
        old.`user_updated`,
        null, 'delete', sysdate());

