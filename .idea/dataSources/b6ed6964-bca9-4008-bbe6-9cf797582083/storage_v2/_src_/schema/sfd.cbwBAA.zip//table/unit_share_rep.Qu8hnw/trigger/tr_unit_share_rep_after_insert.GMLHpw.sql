create trigger tr_unit_share_rep_after_insert
  after INSERT
  on unit_share_rep
  for each row
  insert history.unit_share_rep values(
		 new.`id`
		, new.`version`
		, new.`asset_dev_rep_id`
		, new.`ch_cash_inflow`
		, new.`ch_cash_outflow`
		, new.`ch_new_issued`
		, new.`ch_outstanding`
		, new.`ch_price`
		, new.`ch_redeemed`
		, new.`date_created`
		, new.`last_updated`
		, new.`tot_cash_inflow`
		, new.`tot_cash_outflow`
		, new.`tot_new_issued`
		, new.`tot_outstanding`
		, new.`tot_price`
		, new.`tot_redeemed`
		, new.`unit_share_id`
		, new.`user_created`
		, new.`user_updated`
	, null, 'insert', sysdate());

