create trigger tr_news_content_after_delete
  after DELETE
  on news_content
  for each row
  insert history.news_content values(
    old.`id`,
    old.`version`,
    old.`date_created`,
    old.`document_id`,
    old.`document_name`,
    old.`image_id`,
    old.`last_updated`,
    old.`partner_id`,
    old.`qualified_only`,
    old.`text`,
    old.`title`,
    old.`type`,
    old.`url`,
    old.`user_created`,
    old.`user_updated`,
    null, 'delete', sysdate());

