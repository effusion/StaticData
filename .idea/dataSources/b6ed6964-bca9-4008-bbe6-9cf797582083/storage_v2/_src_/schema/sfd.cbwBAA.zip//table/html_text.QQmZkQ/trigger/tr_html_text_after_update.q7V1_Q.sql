create trigger tr_html_text_after_update
  after UPDATE
  on html_text
  for each row
  insert history.html_text values(
	  new.`id`
	  , new.`version`
	  , new.`name`
	  , new.`text`
	  , null, 'update', sysdate());

