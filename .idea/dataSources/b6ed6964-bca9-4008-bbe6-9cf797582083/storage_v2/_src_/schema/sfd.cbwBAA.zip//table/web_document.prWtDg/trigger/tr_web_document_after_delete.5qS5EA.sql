create trigger tr_web_document_after_delete
  after DELETE
  on web_document
  for each row
  insert history.web_document values(
		 old.`id`
		, old.`version`
		, old.`category`
		, old.`content_meta_data_id`
		, old.`date_created`
		, old.`description`
		, old.`filename`
		, old.`key_date`
		, old.`language`
		, old.`last_updated`
		, old.`user_created`
		, old.`user_updated`
	, null, 'delete', sysdate());

