create trigger tr_logo_after_update
  after UPDATE
  on logo
  for each row
  insert history.logo values(
		 new.`id`
		, new.`version`
		, new.`big_logo_id`
		, new.`small_logo_id`
	, null, 'update', sysdate());

