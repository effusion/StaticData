create trigger tr_business_day_after_delete
  after DELETE
  on business_day
  for each row
  insert history.business_day values(
		 old.`id`
		, old.`version`
		, old.`business`
		, old.`date`
		, old.`date_created`
		, old.`last_updated`
		, old.`user_created`
		, old.`user_updated`
	, null, 'delete', sysdate());

