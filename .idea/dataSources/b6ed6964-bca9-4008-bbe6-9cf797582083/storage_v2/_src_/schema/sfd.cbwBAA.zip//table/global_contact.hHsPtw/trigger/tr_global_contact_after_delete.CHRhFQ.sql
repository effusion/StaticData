create trigger tr_global_contact_after_delete
  after DELETE
  on global_contact
  for each row
  insert history.global_contact values(
		 old.`id`
		, old.`version`
		, old.`city`
		, old.`country`
		, old.`date_created`
		, old.`last_updated`
		, old.`mail`
		, old.`name`
		, old.`phone`
		, old.`role`
		, old.`street`
		, old.`url`
		, old.`user_created`
		, old.`user_updated`
		, old.`zip_code`
    , null
    , 'delete'
    , sysdate());

