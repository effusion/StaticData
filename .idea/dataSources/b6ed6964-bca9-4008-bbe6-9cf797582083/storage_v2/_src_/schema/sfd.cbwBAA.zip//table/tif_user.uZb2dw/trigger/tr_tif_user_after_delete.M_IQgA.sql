create trigger tr_tif_user_after_delete
  after DELETE
  on tif_user
  for each row
  insert history.tif_user values(
    old.`id`,
    old.`version`,
    old.`date_created`,
    old.`last_login`,
    old.`last_updated`,
    old.`mail`,
    old.`name`,
    old.`partner_id`,
    old.`password`,
    old.`public_key`,
    old.`receives_daily_price_reminder`,
    old.`role`,
    old.`user_created`,
    old.`user_updated`,
    old.`username`,
    null, 'delete', sysdate());

