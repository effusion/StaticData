create trigger tr_promoter_mapping_after_delete
  after DELETE
  on promoter_mapping
  for each row
  insert history.promoter_mapping values(
    old.`id`,
    old.`version`,
    old.`name`,
    old.`promoter_id`,
    null, 'delete', sysdate());

