create trigger tr_snb_report_after_insert
  after INSERT
  on snb_report
  for each row
  insert history.snb_report values(
    new.`id`
    , new.`version`
    , new.`asset_struct_rep_id`
    , new.`content_meta_data_id`
    , new.`date_created`
    , new.`last_updated`
    , new.`name`
    , new.`user_created`
    , new.`user_updated`
    , null, 'insert', sysdate()
);

