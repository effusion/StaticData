create trigger tr_message_after_update
  after UPDATE
  on message
  for each row
  insert history.message values(
    new.`id`,
    new.`version`,
    new.`body`,
    new.`content_type`,
    new.`date_created`,
    new.`last_updated`,
    new.`partner_id`,
    new.`subject`,
    new.`type`,
    new.`unread`,
    new.`user_created`,
    new.`user_updated`,
    new.`valid_from`,
    new.`valid_until`,
    null, 'update', sysdate());

