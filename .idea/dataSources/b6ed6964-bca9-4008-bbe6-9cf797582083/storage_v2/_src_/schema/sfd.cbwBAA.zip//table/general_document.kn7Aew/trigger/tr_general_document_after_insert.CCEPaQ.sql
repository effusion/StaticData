create trigger tr_general_document_after_insert
  after INSERT
  on general_document
  for each row
  insert history.general_document values(
		 new.`id`
		, new.`version`
		, new.`content_meta_data_id`
		, new.`date_created`
		, new.`description`
		, new.`file_name`
		, new.`language`
		, new.`last_updated`
		, new.`name`
		, new.`participant_id`
		, new.`public_document`
		, new.`user_created`
		, new.`user_updated`
	, null, 'insert', sysdate());

