create trigger tr_representative_mail_after_insert
  after INSERT
  on representative_mail
  for each row
  insert history.representative_mail values(
     new.`id`
		,new.`version`
    ,new.`announcement`
    ,new.`email`
    ,new.`language`
    ,new.`legal`
    ,new.`marketing`
		,new.`representative_id`
    ,null, 'insert', sysdate());

