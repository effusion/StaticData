create trigger tr_logo_after_delete
  after DELETE
  on logo
  for each row
  insert history.logo values(
		 old.`id`
		, old.`version`
		, old.`big_logo_id`
		, old.`small_logo_id`
	, null, 'delete', sysdate());

