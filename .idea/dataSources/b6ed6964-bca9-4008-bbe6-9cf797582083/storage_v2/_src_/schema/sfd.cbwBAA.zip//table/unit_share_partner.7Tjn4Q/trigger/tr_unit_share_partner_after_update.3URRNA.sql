create trigger tr_unit_share_partner_after_update
  after UPDATE
  on unit_share_partner
  for each row
  insert history.unit_share_partner values(
		 new.`unit_share_recipients_id`
		, new.`partner_id`
	, null, 'update', sysdate());

