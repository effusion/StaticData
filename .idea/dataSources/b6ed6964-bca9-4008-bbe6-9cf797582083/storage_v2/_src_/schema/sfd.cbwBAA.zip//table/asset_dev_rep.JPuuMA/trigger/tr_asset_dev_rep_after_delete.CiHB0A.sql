create trigger tr_asset_dev_rep_after_delete
  after DELETE
  on asset_dev_rep
  for each row
  insert history.asset_dev_rep values(
		 old.`id`
		, old.`version`
		, old.`ch_cash_inflow`
		, old.`ch_cash_outflow`
		, old.`ch_change_net_assets`
		, old.`ch_crossborder_sec_transfer`
		, old.`ch_distributions`
		, old.`ch_investment_result`
		, old.`ch_net_assets`
		, old.`ch_net_cashflow`
		, old.`ch_other_changes`
		, old.`ch_own_dis_invest_same_prom_ot`
		, old.`ch_own_dis_investments`
		, old.`ch_own_invest_same_prom_other`
		, old.`ch_own_investments`
		, old.`ch_own_new_invest_same_prom_ot`
		, old.`ch_own_new_investments`
		, old.`ctrl_is_delivered_to_snb`
		, old.`ctrl_key_month`
		, old.`date_created`
		, old.`key_date`
		, old.`last_updated`
		, null 
		, old.`reporting_currency`
		, old.`sub_fund_id`
		, old.`tot_cash_inflow`
		, old.`tot_cash_outflow`
		, old.`tot_change_net_assets`
		, old.`tot_crossborder_sec_transfer`
		, old.`tot_distributions`
		, old.`tot_investment_result`
		, old.`tot_net_assets`
		, old.`tot_net_cashflow`
		, old.`tot_other_changes`
		, old.`tot_own_dis_invest_same_prom_ot`
		, old.`tot_own_dis_investments`
		, old.`tot_own_invest_same_prom_other`
		, old.`tot_own_investments`
		, old.`tot_own_new_invest_same_prom_ot`
		, old.`tot_own_new_investments`
		, old.`user_created`
		, old.`user_updated`
	, null, 'delete', sysdate());

