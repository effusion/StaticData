create trigger tr_dyn_enum_after_delete
  after DELETE
  on dyn_enum
  for each row
  insert history.dyn_enum values(
		 old.`id`
		, old.`version`
		, old.`category`
		, old.`code`
		, old.`date_created`
		, old.`description`
		, old.`english`
		, old.`french`
		, old.`german`
		, old.`italian`
		, old.`last_updated`
		, old.`system`
		, old.`text`
		, old.`type`
		, old.`user_created`
		, old.`user_updated`
	, null, 'delete', sysdate());

