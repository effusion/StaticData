create trigger tr_my_fund_user_unit_share_after_delete
  after DELETE
  on my_fund_user_unit_share
  for each row
  insert history.my_fund_user_unit_share values(
		 old.`my_fund_user_unit_shares_id`
		, old.`unit_share_id`
	, null, 'delete', sysdate());

