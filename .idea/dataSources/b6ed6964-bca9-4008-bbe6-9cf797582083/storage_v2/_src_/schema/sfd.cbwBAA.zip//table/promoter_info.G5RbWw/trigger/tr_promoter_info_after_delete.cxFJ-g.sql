create trigger tr_promoter_info_after_delete
  after DELETE
  on promoter_info
  for each row
  insert history.promoter_info values(
		 old.`id`
		, old.`version`
    , old.`brief_portrait`
    , old.`document_id`
    , old.`doc_name`
    , old.`field_value1`
    , old.`field_value2`
    , old.`field_value3`
    , old.`field_value4`
    , old.`field_value5`
    , old.`language`
    , old.`promoter_id`
    , null
    , 'delete'
    , sysdate());

