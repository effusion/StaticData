create trigger tr_asset_dev_rep_after_update
  after UPDATE
  on asset_dev_rep
  for each row
  insert history.asset_dev_rep values(
		 new.`id`
		, new.`version`
		, new.`ch_cash_inflow`
		, new.`ch_cash_outflow`
		, new.`ch_change_net_assets`
		, new.`ch_crossborder_sec_transfer`
		, new.`ch_distributions`
		, new.`ch_investment_result`
		, new.`ch_net_assets`
		, new.`ch_net_cashflow`
		, new.`ch_other_changes`
		, new.`ch_own_dis_invest_same_prom_ot`
		, new.`ch_own_dis_investments`
		, new.`ch_own_invest_same_prom_other`
		, new.`ch_own_investments`
		, new.`ch_own_new_invest_same_prom_ot`
		, new.`ch_own_new_investments`
		, new.`ctrl_is_delivered_to_snb`
		, new.`ctrl_key_month`
		, new.`date_created`
		, new.`key_date`
		, new.`last_updated`
		, null 
		, new.`reporting_currency`
		, new.`sub_fund_id`
		, new.`tot_cash_inflow`
		, new.`tot_cash_outflow`
		, new.`tot_change_net_assets`
		, new.`tot_crossborder_sec_transfer`
		, new.`tot_distributions`
		, new.`tot_investment_result`
		, new.`tot_net_assets`
		, new.`tot_net_cashflow`
		, new.`tot_other_changes`
		, new.`tot_own_dis_invest_same_prom_ot`
		, new.`tot_own_dis_investments`
		, new.`tot_own_invest_same_prom_other`
		, new.`tot_own_investments`
		, new.`tot_own_new_invest_same_prom_ot`
		, new.`tot_own_new_investments`
		, new.`user_created`
		, new.`user_updated`
    , null, 'update', sysdate());

