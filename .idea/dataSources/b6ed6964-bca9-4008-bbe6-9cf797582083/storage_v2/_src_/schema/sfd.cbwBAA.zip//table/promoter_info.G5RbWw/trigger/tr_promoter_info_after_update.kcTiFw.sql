create trigger tr_promoter_info_after_update
  after UPDATE
  on promoter_info
  for each row
  insert history.promoter_info values(
		 new.`id`
		, new.`version`
    , new.`brief_portrait`
    , new.`document_id`
    , new.`doc_name`
    , new.`field_value1`
    , new.`field_value2`
    , new.`field_value3`
    , new.`field_value4`
    , new.`field_value5`
    , new.`language`
    , new.`promoter_id`
    , null
    , 'update'
    , sysdate());

