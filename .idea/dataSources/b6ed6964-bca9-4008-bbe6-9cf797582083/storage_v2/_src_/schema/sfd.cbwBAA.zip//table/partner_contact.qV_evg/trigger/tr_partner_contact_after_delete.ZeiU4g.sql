create trigger tr_partner_contact_after_delete
  after DELETE
  on partner_contact
  for each row
  insert history.partner_contact values(
		 old.`id`
		, old.`version`
		, old.`city`
		, old.`country`
		, old.`date_created`
		, old.`last_updated`
		, old.`mail`
		, old.`name`
		, old.`partner_id`
		, old.`phone`
		, old.`reference`
		, old.`role`
		, old.`street`
		, old.`url`		, old.`user_created`
		, old.`user_updated`
		, old.`zip_code`
	, null, 'delete', sysdate());

