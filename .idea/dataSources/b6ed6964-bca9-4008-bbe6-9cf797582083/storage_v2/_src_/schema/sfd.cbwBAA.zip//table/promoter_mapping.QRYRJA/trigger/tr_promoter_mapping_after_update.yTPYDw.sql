create trigger tr_promoter_mapping_after_update
  after UPDATE
  on promoter_mapping
  for each row
  insert history.promoter_mapping values(
    new.`id`,
    new.`version`,
    new.`name`,
    new.`promoter_id`,
    null, 'update', sysdate());

