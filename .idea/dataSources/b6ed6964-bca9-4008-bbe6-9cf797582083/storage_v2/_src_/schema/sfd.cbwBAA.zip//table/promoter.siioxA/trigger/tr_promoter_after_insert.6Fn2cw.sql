create trigger tr_promoter_after_insert
  after INSERT
  on promoter
  for each row
  insert history.promoter values(
	 new.`id`
	, new.`version`
    , new.field_type1
    , new.field_type2
    , new.field_type3
    , new.field_type4
    , new.field_type5
	, new.`logo_id`
	, new.`overriding_group_of_promoter_id`
	, new.`partner_id`
	, null	, null, 'insert', sysdate());

