create trigger tr_representative_after_delete
  after DELETE
  on representative
  for each row
  insert history.representative values(
     old.`id`
		,old.`version`
    ,old.`partner_id`
    ,null, 'delete', sysdate());

